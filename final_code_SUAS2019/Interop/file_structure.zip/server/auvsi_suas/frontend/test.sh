karma start auvsi_suas.conf.karma.js --single-run --browsers Chrome
