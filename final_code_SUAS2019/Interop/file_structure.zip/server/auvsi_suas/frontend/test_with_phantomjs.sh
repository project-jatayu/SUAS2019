export PHANTOMJS_BIN=/usr/local/lib/node_modules/phantomjs/bin/phantomjs
karma start auvsi_suas.conf.karma.js --browsers PhantomJS --single-run
