from django.apps import AppConfig


class AuvsiSuasConfig(AppConfig):
    name = 'auvsi_suas'
