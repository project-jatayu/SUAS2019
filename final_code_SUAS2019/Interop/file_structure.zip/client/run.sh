#!/bin/bash
# Runs the Interop Client in a container.

docker run --net=host --interactive --tty auvsisuas/interop-client
