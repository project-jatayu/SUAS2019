from math import *
def metrestolatlong(localx, localy, ogoriginx, ogoriginy):
#	print("In metlatlong")
#	print(localx,localy)
	xpos = localx*(1.33*20)/500
	ypos = localy*20/(500)
#	print(xpos,ypos)
	xpos = xpos*0.000008998
	newlat = ogoriginx + xpos
	ypos = ypos*0.000008975
	newlong =  ogoriginy + ypos/cos(ogoriginx * pi/180)
	return (newlat,newlong)
	
