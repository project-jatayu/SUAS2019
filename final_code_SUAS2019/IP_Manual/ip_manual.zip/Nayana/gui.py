from flask import Flask, render_template, request, redirect
import gui_imageops
import numpy as np
import pandas as pd
import json
from PIL import Image
import sys
#sys.path.append('/Users/nayana/projects/flask1/interop/client')
from auvsi_suas.client import client
from auvsi_suas.proto import interop_api_pb2
import datetime
import time
from FindLatLong import metrestolatlong
xt = time.time()
ipadd = 'http://127.0.0.1:4321/workspace/interop/time.csv'
ts=0
import AdvancedHTMLParser

path = '/home/adityakishore/Desktop/Nayana/static/images'

parser = AdvancedHTMLParser.AdvancedHTMLParser()
parser.parseFile('/home/adityakishore/Desktop/Nayana/templates/html/gui_form.html')
myImage=parser.getElementById('MainImage')

app = Flask(__name__)
#app.debug = True

colours = ['white', 'black', 'gray', 'red', 'blue', 'green', 'yellow', 'purple', 'brown', 'orange'] 
shapes = ['circle', 'semicircle', 'quarter circle', 'triangle','square', 'rectangle', 'trapezoid', 'pentagon', 'hexagon', 'heptagon', 'octagon', 'star', 'cross']
orientations = ['N','NE','E','SE','S','SW','W','NW']
alphanumeric = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','3','4','5','6','7','8','9','0']

dict_orient =	{"N":1, "NE":2, "E":3, "SE":4, "S":5, "SW":6, "W":7, "NW":8}

dict_shape =	{ "circle":1, "semicircle":2, "quarter circle":3, "triangle":4, "square":5, "rectangle":6, "†rapezoid":7, "pentagon":8, "hexagon":9, "heptagon":10, "octagon":11, "star":12, "cross":13}

dict_colour = {'white':1, 'black':2, 'gray':3, 'red':4, 'blue':5, 'green':6, 'yellow':7, 'purple':8, 'brown':9, 'orange':10}

im = gui_imageops.ImageVals(0,[])

client = client.Client(url='http://10.10.130.10:80', username='jatayu', password='2604741296')
#client = client.Client(url='http://127.0.0.1:8000', username='testuser', password='testpass')
#10.10.130.60:80
#jatayu
#2604741296
                       
with open('count.txt', 'r') as f:
   count = int(f.read())
   f.close()
                       
def savetodir(data,send_image):
   global count
   fname = 'data/'+str(count)+'.json'
   with open(fname, 'w') as outfile:
       json.dump(data, outfile)
   with Image.open(send_image) as image: 
      image.save('data/'+str(count)+'.jpg', 'JPEG')
   count+=1
   with open('count.txt', 'w') as f:
      f.write(str(count))
      f.close()

@app.route('/', methods=['GET','POST'])
def dropdown():   
                 
    im.getimg(im.imageArray,im.imageIndex)
    
    if not im.imageArray:
       return "Folder is empty"
       
    else:
       fullpath = im.image_src(im.imageArray,im.imageIndex)
       x = im.image_src(im.imageArray,im.imageIndex).replace(path, '')
       ts=im.metadata(im.imageArray,im.imageIndex)

       return render_template('html/gui_form.html', odlc_l_colours = colours, odlc_s_colours = colours, shapes = shapes,
       orientations = orientations, alphanumeric = alphanumeric, x=str('../../static/images') + x, path = fullpath) 
        
@app.route('/submitForm', methods=['GET','POST'])
def submit_form():
    #print("Get params from form")
    result = request.form
    letter_colour= request.form['letter_colour']
    alphanumericval= request.form['alphanumeric']
    bg_colour= request.form['bg_colour']
    shapeval= request.form['shape']
    orientationval= request.form['orientation']
    leftupperx= request.form['leftupperX']
    leftuppery= request.form['leftupperY']
    rightlowerx= request.form['rightlowerX']
    rightlowery= request.form['rightlowerY']
    TX = request.form['TargetX']
    TY = request.form['TargetY']
    print('X')
    tx = int(TX)
    ty = int(TY)
    orientationval=float(orientationval)
    lat=tx
    lon=ty
    #print("Completed getting params from form")
    df = pd.read_csv(ipadd)
    #print("After reading csv")
    df=df.set_index('time')
    df.index = pd.to_datetime(df.index)
    latlon = df.iloc[df.index.get_loc(ts, method='nearest')]
    oldlat=latlon[0]
    oldlon=latlon[1]
    head = latlon[2]
    print(head)
    neworval = (orientationval+head)%360
    if neworval>(360-22.5) and neworval<22.5:
       orval = 'N'
    elif neworval>(22.5) and neworval<67.5:
       orval = 'NE'
    elif neworval>(67.5) and neworval<112.5:
       orval = 'E'
    elif neworval>(112.5) and neworval<157.5:
       orval = 'SE'
    elif neworval>(157.5) and neworval<202.5:
       orval = 'S'
    elif neworval>(202.5) and neworval<247.5:
       orval = 'SW'
    elif neworval>(247.5) and neworval<292.5:
       orval = 'W'
    elif neworval>(292.5) and neworval<337.5:
       orval = 'NW'

    #print("Old lat and lon")
    #print(oldlat)
    #print(oldlon)
    lat,lon = metrestolatlong(tx,ty,oldlat,oldlon)
    #print("Lat and lon")
    #print(lat)
    #print(lon)

    # lat,lon = findlatlon(tx,ty)
    send_image = im.image_srcShrutheesh(im.imageArray,im.imageIndex, leftupperx, leftuppery, rightlowerx, rightlowery)
    #print("Image to be sent:")
    #print(send_image)

    latlon=im.metadata(im.imageArray,im.imageIndex)
    
    odlc = interop_api_pb2.Odlc()
    
    odlc.type = interop_api_pb2.Odlc.STANDARD
    odlc.latitude=lat
    odlc.longitude=lon
    odlc.orientation = dict_orient[orval]
    print(orval)
    print("###")
    print(dict_orient[orval])
    odlc.shape=dict_shape[shapeval]
    odlc.shape_color=dict_colour[bg_colour]
    odlc.alphanumeric=alphanumericval
    odlc.alphanumeric_color=dict_colour[letter_colour]
    odlc.mission = 3
    
    data = {
       "type" : "standard",
       "latitude" : odlc.latitude,  
       "longitude" : odlc.longitude,  
       "orientation" : orval,
       "shape" : shapeval, 
       "background_color" : bg_colour,  
       "alphanumeric" : alphanumericval,  
       "alphanumeric_color" : letter_colour
    }
    
    #print("Before submitting")
    odlc = client.post_odlc(odlc)
    #print("After submitting data")
    savetodir(data,'static/dummyimagefolder/image.jpg')

    with open('static/dummyimagefolder/image.jpg', 'rb') as f:
        image_data = f.read()
        client.put_odlc_image(odlc.id, image_data)       
    #print("After submitting image")
    return redirect("/")
    
@app.route('/previous', methods=['GET','POST'])
def previous_image():
    im.previousimg(im.imageArray,im.imageIndex,myImage)   
    return redirect("/")

@app.route('/next', methods=['GET','POST'])
def next_image():
    im.nextimg(im.imageArray,im.imageIndex,myImage)
    return redirect("/")
    
@app.route('/change', methods=['GET','POST'])
def delete_image():
    im.deleteimg(im.imageArray,im.imageIndex)
    return redirect("/")
    
@app.route('/move', methods=['GET','POST'])
def move_image():
    im.moveimg(im.imageArray,im.imageIndex) 
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)
